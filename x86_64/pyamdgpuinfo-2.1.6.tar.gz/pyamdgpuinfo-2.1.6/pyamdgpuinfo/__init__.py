from ._pyamdgpuinfo import GPUInfo, get_gpu, detect_gpus
